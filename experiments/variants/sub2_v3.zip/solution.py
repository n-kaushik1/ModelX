"""
DA5401 Data Analytics Lab -- Course Project
Reusable end-to-end framework for binary tabular classification (version 3).

Public interface (as required by the evaluator):

    sol = StudentSolution()
    sol.fit(X, y, metadata)
    p = sol.predict_proba(X_test, metadata)      # 1-D array, P(y = 1)
    t = sol.get_threshold()                      # float decision threshold

The framework contains no dataset-specific logic.  Everything it does is driven
by (a) measured properties of the training data and (b) the objective that is
supplied via ``metadata`` (primary metric, decision costs, identifier columns).

Workflow implemented in ``fit``
    1. profile the data  : drop identifiers / constants, coerce numeric-like
                           strings, split numeric vs categorical, measure
                           missingness, class balance, cardinality, size.
    2. preprocessing     : model-specific encoders built from the profile
                           (native-NaN + integer codes for gradient boosting,
                           imputed + one-hot for forests, imputed + log /
                           standardise + one-hot (+ splines) for linear models,
                           raw strings for CatBoost).  Unseen / rare categories
                           are mapped to a "rare" bucket; the fitted encoder is
                           always re-applied to test data.
    3. candidates        : prior baseline, spline-logistic GAM, LightGBM,
                           XGBoost, CatBoost, ExtraTrees (HistGradientBoosting
                           only as a fallback when LightGBM is missing).
    4. validation        : stratified K-fold out-of-fold (OOF) predictions.
    5. tuning            : for every boosting family a *complexity ladder*
                           (tree depth 1 ... 6, with the number of trees chosen
                           by early stopping inside each fold) followed by a
                           time-boxed random refinement around the best depth.
                           Scored with the problem's metric, or with log loss
                           (a proper scoring rule) when the metric needs a
                           threshold.  Depth-1 boosting is an additive model,
                           so the ladder measures how much interaction the data
                           really contains instead of assuming deep trees.
    6. selection         : the best config of every family is re-scored on
                           fresh folds with a *fixed* number of trees (no
                           early-stopping optimism), then combined by greedy
                           (Caruana) ensemble selection in logit space.  A
                           single model is chosen if blending does not help.
    7. calibration       : a Platt (sigmoid) map fitted on OOF predictions is
                           kept only if nested CV shows a log-loss gain.  It is
                           monotone, so ranking metrics (AUC) are unaffected.
    8. threshold         : when the metric is decision based (cost, F1, ...)
                           the threshold is chosen on calibrated OOF
                           predictions, taking the median over bootstrap
                           resamples for stability.
    9. refit             : every selected member is refit on all supplied data
                           (several seeds for stochastic learners, number of
                           trees scaled up for the larger training set).
"""

from __future__ import annotations

import os
import re
import time
import warnings
import zlib
from collections.abc import Mapping

import numpy as np
import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import (ExtraTreesClassifier, HistGradientBoostingClassifier,
                              RandomForestClassifier)
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score, average_precision_score, brier_score_loss
from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import SplineTransformer

try:  # optional -- the framework degrades gracefully if LightGBM is missing
    import lightgbm as lgb
    _HAS_LGBM = True
except Exception:  # pragma: no cover
    lgb = None
    _HAS_LGBM = False

try:  # optional -- CatBoost (ordered target statistics for categoricals)
    import catboost as cb
    _HAS_CAT = True
except Exception:  # pragma: no cover
    cb = None
    _HAS_CAT = False

try:  # optional -- XGBoost
    import xgboost as xgb
    _HAS_XGB = True
except Exception:  # pragma: no cover
    xgb = None
    _HAS_XGB = False

warnings.filterwarnings("ignore")

_EPS = 1e-4
def _available_cpus():
    """CPUs this process may actually use (respects container / affinity limits)."""
    try:
        return max(1, len(os.sched_getaffinity(0)))
    except Exception:
        return max(1, os.cpu_count() or 1)


_N_CPU = _available_cpus()


# =============================================================================
# 1. Metadata / objective handling
# =============================================================================
def _flatten(obj, prefix="", out=None, depth=0):
    """Flatten nested mappings into {'a_b_c': value} with lower-case keys."""
    out = {} if out is None else out
    if isinstance(obj, Mapping):
        for k, v in obj.items():
            key = f"{prefix}_{k}" if prefix else str(k)
            if isinstance(v, Mapping) and depth < 3:
                _flatten(v, key.lower(), out, depth + 1)
            else:
                out[key.lower()] = v
    return out


def _to_dict(metadata):
    if metadata is None:
        return {}
    if isinstance(metadata, Mapping):
        return _flatten(metadata)
    try:
        return _flatten(vars(metadata))
    except Exception:
        return {}


def _tokens(key):
    return set(re.split(r"[^a-z0-9]+", key.lower()))


def _norm_metric(name):
    s = re.sub(r"[^a-z0-9]+", "_", str(name).lower()).strip("_")
    if "cost" in s or "expected_loss" in s:
        return "cost"
    if ("pr" in s.split("_") and "auc" in s) or "average_precision" in s or s in ("ap", "auprc"):
        return "average_precision"
    if "auc" in s or "roc" in s or "gini" in s:
        return "roc_auc"
    if "log" in s or "cross_entropy" in s or "entropy" in s or "nll" in s:
        return "log_loss"
    if "brier" in s:
        return "brier"
    if "balanced_acc" in s:
        return "balanced_accuracy"
    if "f1" in s or s == "f_score":
        return "f1"
    if "acc" in s:
        return "accuracy"
    return None


class Objective:
    """Evaluation objective decoded from metadata (with safe defaults)."""

    THRESHOLD_METRICS = ("cost", "f1", "accuracy", "balanced_accuracy")

    def __init__(self, metadata):
        md = _to_dict(metadata)
        self.fp_cost, self.fn_cost = None, None
        self.metric = None
        self.id_columns, self.target_name = [], None

        metric_keys = ("metric", "primary_metric", "eval_metric", "evaluation_metric", "scoring",
                       "objective", "task_metric", "score")
        for k in metric_keys:
            for key, v in md.items():
                if (key == k or key.endswith("_" + k)) and isinstance(v, str):
                    m = _norm_metric(v)
                    if m:
                        self.metric = m
                        break
            if self.metric:
                break

        for key, v in md.items():
            if isinstance(v, bool) or not isinstance(v, (int, float, np.integer, np.floating)):
                continue
            tk = _tokens(key)
            if "cost" in tk or "penalty" in tk or "loss" in tk or "weight" in tk or "fp" in tk or "fn" in tk:
                if "fp" in tk or ("false" in tk and "positive" in tk):
                    self.fp_cost = float(v)
                elif "fn" in tk or ("false" in tk and "negative" in tk):
                    self.fn_cost = float(v)
        if self.fp_cost is not None or self.fn_cost is not None:
            self.fp_cost = 1.0 if self.fp_cost is None else self.fp_cost
            self.fn_cost = 1.0 if self.fn_cost is None else self.fn_cost
            if self.metric is None:
                self.metric = "cost"
        if self.metric == "cost" and self.fp_cost is None:
            self.fp_cost = self.fn_cost = 1.0

        for key, v in md.items():
            tk = _tokens(key)
            if ("id" in tk or "ids" in tk or "identifier" in tk or "identifiers" in tk) and "columns" in tk or key in (
                    "id_col", "id_cols", "id_column", "id_columns", "identifier", "identifiers", "id"):
                if isinstance(v, str):
                    self.id_columns.append(v)
                elif isinstance(v, (list, tuple, set)):
                    self.id_columns += [c for c in v if isinstance(c, str)]
            if key in ("target", "target_col", "target_column", "target_name", "label", "label_column"):
                if isinstance(v, str):
                    self.target_name = v
        # explicit flags used by the leaderboard metadata
        self.requires_threshold = bool(md.get("requires_threshold", False)) if not isinstance(
            md.get("requires_threshold"), str) else md["requires_threshold"].strip().lower() in ("1", "true", "yes")
        self.positive_label = md.get("positive_label", None)
        if self.requires_threshold and self.metric not in self.THRESHOLD_METRICS:
            # a decision is required: use the stated costs, or plain accuracy (equal costs) if none are given
            self.metric = "cost"
            if self.fp_cost is None:
                self.fp_cost = self.fn_cost = 1.0
        if self.metric is None:
            self.metric = "log_loss"          # proper scoring rule: a safe default
            self.metric_was_default = True
        else:
            self.metric_was_default = False

    # ---- score helpers (all "higher is better") ------------------------------
    @property
    def uses_threshold(self):
        return self.metric in self.THRESHOLD_METRICS

    @property
    def tune_metric(self):
        """Metric used during hyper-parameter search (threshold-free)."""
        return "log_loss" if self.uses_threshold or self.metric in ("brier",) else self.metric

    def describe(self):
        d = {"metric": self.metric, "metric_defaulted": self.metric_was_default}
        if self.metric == "cost":
            d.update(fp_cost=self.fp_cost, fn_cost=self.fn_cost)
        return d


def _clip(p):
    return np.clip(np.asarray(p, dtype=float), _EPS, 1 - _EPS)


def _score_free(metric, y, p):
    """Threshold-free metrics, oriented so that larger is better."""
    if len(np.unique(y)) < 2:
        return 0.0
    if metric == "roc_auc":
        return roc_auc_score(y, p)
    if metric == "average_precision":
        return average_precision_score(y, p)
    if metric == "log_loss":
        return -log_loss(y, _clip(p), labels=[0, 1])
    if metric == "brier":
        return -brier_score_loss(y, p)
    raise ValueError(metric)


def _conf_curve(y, p):
    """Confusion counts for every distinct threshold (positive iff p >= thr),
    preceded by the "nobody is positive" option."""
    y = np.asarray(y).astype(int)
    order = np.argsort(-p, kind="mergesort")
    ps, ys = p[order], y[order]
    last = np.r_[ps[1:] != ps[:-1], True]            # last index of each tie group
    cum = np.cumsum(ys)
    tp = cum[last]
    fp = (np.arange(1, len(ys) + 1) - cum)[last]
    thr = ps[last]
    P, N = y.sum(), len(y) - y.sum()
    thr = np.r_[np.nextafter(thr[0], np.inf), thr]
    tp, fp = np.r_[0, tp], np.r_[0, fp]
    return thr, tp, fp, P - tp, N - fp


def _threshold_metric_from_counts(metric, tp, fp, fn, tn, obj):
    n = tp + fp + fn + tn
    if metric == "cost":
        return -(obj.fp_cost * fp + obj.fn_cost * fn) / n          # per-sample cost, negated
    if metric == "accuracy":
        return (tp + tn) / n
    if metric == "balanced_accuracy":
        return 0.5 * (tp / np.maximum(tp + fn, 1) + tn / np.maximum(tn + fp, 1))
    if metric == "f1":
        return 2 * tp / np.maximum(2 * tp + fp + fn, 1)
    raise ValueError(metric)


def _best_threshold(y, p, obj, smooth_window=0):
    """Return (threshold, best_score).  Optionally smooths the score curve."""
    thr, tp, fp, fn, tn = _conf_curve(y, p)
    sc = _threshold_metric_from_counts(obj.metric, tp, fp, fn, tn, obj)
    if smooth_window and len(sc) > smooth_window:
        k = np.ones(smooth_window) / smooth_window
        h = smooth_window // 2
        sm = np.convolve(np.pad(sc, (h, smooth_window - 1 - h), mode="edge"), k, mode="valid")
        i = int(np.argmax(sm))
    else:
        i = int(np.argmax(sc))
    t = thr[i]
    if i + 1 < len(thr):                              # midpoint to the next lower distinct value
        t = 0.5 * (thr[i] + thr[i + 1])
    return float(t), float(sc[i])


def _selection_score(obj, y, p):
    """Score used to pick between models / blends (higher = better)."""
    if obj.uses_threshold:
        _, s = _best_threshold(y, p, obj)
        return s
    return _score_free(obj.metric, y, p)


def _tuning_score(obj, y, p):
    return _score_free(obj.tune_metric, y, p)


# =============================================================================
# 2. Data profiling and cleaning
# =============================================================================
_ID_NAME = re.compile(r"(^|_)(id|ids|uuid|guid|identifier)($|_)|record_?id", re.I)


def _is_id_name(name):
    n = str(name).strip().lower()
    return bool(_ID_NAME.search(n))


class DataCleaner:
    """Learns which columns to keep and how to type them; applies it to new data."""

    def __init__(self, extra_ids=(), target_name=None):
        self.extra_ids = set(extra_ids)
        self.target_name = target_name

    def fit(self, X):
        X = self._as_df(X)
        n = len(X)
        self.dropped_ = {"id": [], "constant": [], "empty": [], "unique_text": [], "unsupported": []}
        self.numeric_, self.categorical_, self.coerced_ = [], [], []
        for c in X.columns:
            s = X[c]
            if c in self.extra_ids or _is_id_name(c) or c == self.target_name:
                self.dropped_["id"].append(c)
                continue
            if pd.api.types.is_datetime64_any_dtype(s) or pd.api.types.is_timedelta64_dtype(s):
                self.dropped_["unsupported"].append(c)
                continue
            if s.isna().all():
                self.dropped_["empty"].append(c)
                continue
            if s.dropna().nunique() <= 1 and s.isna().sum() == 0:
                self.dropped_["constant"].append(c)
                continue
            if pd.api.types.is_bool_dtype(s):
                self.categorical_.append(c)
                continue
            if pd.api.types.is_numeric_dtype(s):
                self.numeric_.append(c)
                continue
            # text-like column: numeric strings -> numeric; unique text -> identifier
            conv = pd.to_numeric(s, errors="coerce")
            nn = s.notna().sum()
            if nn > 0 and conv.notna().sum() >= 0.95 * nn:
                self.numeric_.append(c)
                self.coerced_.append(c)
                continue
            if n >= 50 and s.nunique(dropna=True) >= 0.9 * nn:
                self.dropped_["unique_text"].append(c)
                continue
            self.categorical_.append(c)
        self.columns_ = self.numeric_ + self.categorical_
        return self

    @staticmethod
    def _as_df(X):
        if isinstance(X, pd.DataFrame):
            return X.copy()
        return pd.DataFrame(X)

    def transform(self, X):
        X = self._as_df(X)
        out = pd.DataFrame(index=X.index)
        for c in self.numeric_:
            out[c] = pd.to_numeric(X[c], errors="coerce").astype(float) if c in X else np.nan
        for c in self.categorical_:
            out[c] = X[c].astype("object").where(X[c].notna(), None) if c in X else None
            out[c] = out[c].map(lambda v: None if v is None else str(v))
        out = out.replace([np.inf, -np.inf], np.nan)
        return out


def profile_data(Xc, y, cleaner):
    """Measured data characteristics that drive the framework's decisions."""
    n, p = Xc.shape
    prior = float(np.mean(y))
    prof = {
        "n_rows": n, "n_features": p,
        "n_numeric": len(cleaner.numeric_), "n_categorical": len(cleaner.categorical_),
        "positive_rate": prior,
        "minority_count": int(min(y.sum(), n - y.sum())),
        "imbalanced": bool(min(prior, 1 - prior) < 0.15),
        "missing_rate_overall": float(Xc.isna().mean().mean()) if p else 0.0,
        "n_cols_with_missing": int((Xc.isna().sum() > 0).sum()),
        "max_cardinality": int(max([Xc[c].nunique() for c in cleaner.categorical_] or [0])),
        "dropped": {k: v for k, v in cleaner.dropped_.items() if v},
    }
    if cleaner.numeric_:
        sk = Xc[cleaner.numeric_].skew().abs()
        prof["n_skewed_numeric"] = int((sk > 1).sum())
    return prof


# =============================================================================
# 3. Preprocessing (one encoder, three output modes)
# =============================================================================
class TabularEncoder:
    """
    mode = "native"  : numerics untouched (NaN kept); categoricals -> integer codes
                       (NaN for missing) so that GBMs can use native handling.
    mode = "imputed" : median imputation + missing indicators; one-hot categoricals.
    mode = "linear"  : as "imputed" + log transform of skewed columns, standardise,
                       clip to +-5 sd.
    """

    def __init__(self, mode, max_levels=30, min_freq=0.005, max_onehot=25):
        self.mode = mode
        self.max_levels = max_levels
        self.min_freq = min_freq
        self.max_onehot = max_onehot

    def fit(self, Xc, num_cols, cat_cols):
        self.num_cols, self.cat_cols = list(num_cols), list(cat_cols)
        n = len(Xc)
        thr = max(5, int(self.min_freq * n))
        self.levels_ = {}
        for c in self.cat_cols:
            vc = Xc[c].value_counts()
            keep = [v for v in vc.index if vc[v] >= thr][: self.max_levels]
            self.levels_[c] = keep
        self.freq_ = {c: Xc[c].value_counts(normalize=True).to_dict() for c in self.cat_cols}
        self.onehot_cols_ = [c for c in self.cat_cols if len(self.levels_[c]) <= self.max_onehot]
        self.ordinal_cols_ = [c for c in self.cat_cols if c not in self.onehot_cols_]
        self.median_ = Xc[self.num_cols].median().fillna(0.0) if self.num_cols else pd.Series(dtype=float)
        self.na_cols_ = [c for c in self.num_cols if Xc[c].isna().any()][:100]
        self.log_cols_ = {}
        if self.mode == "linear" and self.num_cols:
            for c in self.num_cols:
                x = Xc[c].dropna()
                if len(x) > 20 and abs(x.skew()) > 1.0 and x.nunique() > 10:
                    self.log_cols_[c] = bool((x >= 0).all())
            Z = self._numeric_block(Xc, fitting=True)
            self.mu_, self.sd_ = Z.mean(0), Z.std(0)
            self.sd_[self.sd_ < 1e-12] = 1.0
        self.feature_names_ = self._names()
        self.cat_idx_ = self._cat_idx()
        return self

    # -- helpers --------------------------------------------------------------
    def _cat_idx(self):
        base = len(self.num_cols)
        if self.mode == "frame":
            return [base + i for i in range(len(self.cat_cols))]
        if self.mode != "native":
            return []
        return [base + i for i, c in enumerate(self.cat_cols) if len(self.levels_[c]) + 1 <= 30]

    def _names(self):
        names = list(self.num_cols)
        if self.mode in ("native", "frame"):
            return names + [f"{c}__code" for c in self.cat_cols]
        names += [f"{c}__isna" for c in self.na_cols_]
        for c in self.onehot_cols_:
            names += [f"{c}={l}" for l in self.levels_[c]] + [f"{c}=__rare__", f"{c}=__na__"]
        names += [f"{c}__code" for c in self.ordinal_cols_]
        names += [f"{c}__freq" for c in self.cat_cols if c in self.ordinal_cols_]
        return names

    def _map_cat(self, s, c):
        lv = self.levels_[c]
        idx = {v: i for i, v in enumerate(lv)}
        rare = len(lv)
        return s.map(lambda v: np.nan if v is None or (isinstance(v, float) and np.isnan(v))
                     else float(idx.get(v, rare)))

    def _numeric_block(self, Xc, fitting=False):
        Z = Xc[self.num_cols].to_numpy(dtype=float).copy() if self.num_cols else np.zeros((len(Xc), 0))
        if self.mode in ("native", "frame"):
            return Z
        med = self.median_.to_numpy()
        for j, c in enumerate(self.num_cols):
            m = np.isnan(Z[:, j])
            Z[m, j] = med[j]
        if self.mode == "linear":
            for j, c in enumerate(self.num_cols):
                if c in self.log_cols_:
                    z = Z[:, j]
                    Z[:, j] = np.log1p(np.maximum(z, 0)) if self.log_cols_[c] else np.sign(z) * np.log1p(np.abs(z))
        return Z

    def transform(self, Xc):
        n = len(Xc)
        Z = self._numeric_block(Xc)
        if self.mode == "frame":                       # CatBoost: numerics with NaN + string categories
            out = pd.DataFrame(Z, columns=[f"n{j}" for j in range(Z.shape[1])])
            for j, c in enumerate(self.cat_cols):
                known = set(self.levels_[c])
                out[f"c{j}"] = [("__na__" if v is None or (isinstance(v, float) and v != v)
                                 else (v if v in known else "__rare__")) for v in Xc[c].tolist()]
            return out
        if self.mode == "native":
            cats = [self._map_cat(Xc[c], c).to_numpy(dtype=float)[:, None] for c in self.cat_cols]
            return np.hstack([Z] + cats) if cats else Z
        if self.mode == "linear" and self.num_cols:
            Z = np.clip((Z - self.mu_) / self.sd_, -5, 5)
        blocks = [Z]
        if self.na_cols_:
            blocks.append(Xc[self.na_cols_].isna().to_numpy(dtype=float))
        for c in self.onehot_cols_:
            lv = self.levels_[c]
            codes = self._map_cat(Xc[c], c).to_numpy()
            oh = np.zeros((n, len(lv) + 2))
            isna = np.isnan(codes)
            ok = ~isna
            oh[np.where(ok)[0], codes[ok].astype(int)] = 1.0
            oh[isna, len(lv) + 1] = 1.0
            blocks.append(oh)
        for c in self.ordinal_cols_:
            codes = self._map_cat(Xc[c], c).to_numpy()
            blocks.append(np.where(np.isnan(codes), -1.0, codes)[:, None])
        for c in self.ordinal_cols_:
            blocks.append(Xc[c].map(self.freq_[c]).fillna(0.0).to_numpy(dtype=float)[:, None])
        return np.hstack(blocks)


# =============================================================================
# 4. Candidate model families
# =============================================================================
class ModelSpec:
    """A (family, hyper-parameters) pair that can be fitted on a cleaned frame."""

    def __init__(self, family, params, seed=0):
        self.family, self.params, self.seed = family, dict(params), seed

    def label(self):
        return f"{self.family}({', '.join(f'{k}={self._fmt(v)}' for k, v in self.params.items())})"

    @staticmethod
    def _fmt(v):
        return f"{v:.4g}" if isinstance(v, float) else str(v)


_FAMILY_MODE = {"prior": "imputed", "logreg": "linear", "gam": "linear", "hgb": "native", "lgbm": "native",
                "rf": "imputed", "et": "imputed", "cat": "frame", "xgb": "native"}
_BOOSTERS = ("lgbm", "xgb", "cat")
_MAX_TREES = {"lgbm": 4000, "xgb": 4000, "cat": 3000}
_PATIENCE = {"lgbm": 150, "xgb": 150, "cat": 100}


class SplineLogit:
    """Logistic regression on cubic B-spline bases of the (standardised) numeric columns, i.e. a
    regularised additive model (GAM).  Columns with few distinct values stay linear."""

    def __init__(self, n_numeric, C=0.3, n_knots=8):
        self.n_numeric, self.C, self.n_knots = n_numeric, C, n_knots

    def _design(self, Z, fitting=False):
        if fitting:
            nun = [len(np.unique(Z[:, j])) for j in range(self.n_numeric)]
            self.spline_cols_ = [j for j in range(self.n_numeric) if nun[j] > 10]
            if self.spline_cols_:
                self.spline_ = SplineTransformer(n_knots=self.n_knots, degree=3, knots="quantile",
                                                 include_bias=False).fit(Z[:, self.spline_cols_])
        blocks = [Z]
        if self.spline_cols_:
            blocks.append(self.spline_.transform(Z[:, self.spline_cols_]))
        return np.hstack(blocks)

    def fit(self, Z, y):
        D = self._design(np.asarray(Z, dtype=float), fitting=True)
        self.lr_ = LogisticRegression(C=self.C, max_iter=3000, solver="lbfgs").fit(D, y)
        return self

    def predict_proba(self, Z):
        return self.lr_.predict_proba(self._design(np.asarray(Z, dtype=float)))


class FittedModel:
    def __init__(self, spec, enc, est, best_iter=None):
        self.spec, self.enc, self.est, self.best_iter = spec, enc, est, best_iter

    def predict(self, Xc):
        Z = self.enc.transform(Xc)
        p = self.est.predict_proba(Z)[:, 1]
        return np.asarray(p, dtype=float)


def _leaves_for(depth, leaves):
    """Number of leaves consistent with a depth limit."""
    return int(max(2, min(leaves, 2 ** depth)))


def _fit_model(spec, Xc, y, num_cols, cat_cols, obj, n_jobs, eval_data=None):
    """Fit one candidate.  ``eval_data=(Xv, yv)`` enables early stopping for the boosting
    families (used during tuning only); the number of trees found is stored on the result."""
    fam, P, seed = spec.family, spec.params, spec.seed
    mode = _FAMILY_MODE[fam]
    # CatBoost copes with high-cardinality categoricals itself, so keep (many) more levels for it
    enc = TabularEncoder(mode, max_levels=1000 if mode == "frame" else 30).fit(Xc, num_cols, cat_cols)
    Z = enc.transform(Xc)
    Zv = yv = None
    if eval_data is not None and fam in _BOOSTERS:
        Zv, yv = enc.transform(eval_data[0]), eval_data[1]
    cw = P.get("class_weight")
    best_iter = None
    if fam == "prior":
        est = DummyClassifier(strategy="prior").fit(Z, y)
    elif fam == "logreg":
        est = LogisticRegression(C=P["C"], class_weight=cw, max_iter=2000, solver="lbfgs").fit(Z, y)
    elif fam == "gam":
        est = SplineLogit(len(num_cols), C=P["C"], n_knots=P["knots"]).fit(Z, y)
    elif fam == "hgb":
        est = HistGradientBoostingClassifier(
            learning_rate=P["lr"], max_iter=P.get("n_estimators", 600), max_depth=P["depth"],
            max_leaf_nodes=_leaves_for(P["depth"], P["leaves"]), min_samples_leaf=P["min_leaf"],
            l2_regularization=P["l2"], max_features=P["colsample"], max_bins=255, class_weight=cw,
            early_stopping=True, validation_fraction=0.15, n_iter_no_change=30, scoring="loss",
            random_state=seed, categorical_features=enc.cat_idx_ if enc.cat_idx_ else None).fit(Z, y)
    elif fam == "lgbm":
        n_trees = P.get("n_estimators") or _MAX_TREES[fam]
        est = lgb.LGBMClassifier(
            n_estimators=n_trees, learning_rate=P["lr"], num_leaves=_leaves_for(P["depth"], P["leaves"]),
            max_depth=P["depth"] if P["depth"] <= 8 else -1, min_child_samples=P["min_leaf"],
            subsample=P["subsample"], subsample_freq=1, colsample_bytree=P["colsample"],
            reg_lambda=P["l2"], reg_alpha=P.get("l1", 0.0), class_weight=cw, random_state=seed,
            n_jobs=n_jobs, verbose=-1, cat_smooth=20, min_data_per_group=50)
        kw = dict(categorical_feature=enc.cat_idx_ if enc.cat_idx_ else "auto")
        if Zv is not None:
            est.fit(Z, y, eval_set=[(Zv, yv)], callbacks=[lgb.early_stopping(_PATIENCE[fam], verbose=False)], **kw)
            best_iter = int(est.best_iteration_ or n_trees)
        else:
            est.fit(Z, y, **kw)
    elif fam == "cat":
        n_trees = P.get("n_estimators") or _MAX_TREES[fam]
        ckw = dict(iterations=n_trees, learning_rate=P["lr"], depth=P["depth"], l2_leaf_reg=P["l2"],
                   random_strength=P["random_strength"], bagging_temperature=P["bagging_temperature"],
                   random_seed=seed, thread_count=n_jobs, verbose=0, allow_writing_files=False)
        if cw:
            ckw["auto_class_weights"] = "Balanced"
        if enc.cat_idx_:
            ckw["cat_features"] = enc.cat_idx_
        if Zv is not None:
            ckw.update(od_type="Iter", od_wait=_PATIENCE[fam])
        est = cb.CatBoostClassifier(**ckw)
        if Zv is not None:
            est.fit(Z, y, eval_set=(Zv, yv), use_best_model=True)
            best_iter = int(est.get_best_iteration() or 0) + 1
        else:
            est.fit(Z, y)
    elif fam == "xgb":
        n_trees = P.get("n_estimators") or _MAX_TREES[fam]
        spw = float((len(y) - y.sum()) / max(y.sum(), 1)) if cw else 1.0
        est = xgb.XGBClassifier(
            n_estimators=n_trees, learning_rate=P["lr"], max_depth=P["depth"], min_child_weight=P["mcw"],
            subsample=P["subsample"], colsample_bytree=P["colsample"], reg_lambda=P["l2"],
            reg_alpha=P.get("l1", 0.0), scale_pos_weight=spw, tree_method="hist", n_jobs=n_jobs,
            random_state=seed, verbosity=0, eval_metric="logloss",
            early_stopping_rounds=_PATIENCE[fam] if Zv is not None else None)
        if Zv is not None:
            est.fit(Z, y, eval_set=[(Zv, yv)], verbose=False)
            best_iter = int(est.best_iteration) + 1
        else:
            est.fit(Z, y)
    elif fam in ("rf", "et"):
        cls = RandomForestClassifier if fam == "rf" else ExtraTreesClassifier
        est = cls(n_estimators=P["n_estimators"], min_samples_leaf=P["min_leaf"],
                  max_features=P["max_features"], class_weight=cw, n_jobs=n_jobs,
                  random_state=seed).fit(Z, y)
    else:
        raise ValueError(fam)
    return FittedModel(spec, enc, est, best_iter)


# ---- search spaces -----------------------------------------------------------
# Stage 1 of the search is a "complexity ladder": one configuration per tree depth, with the
# number of trees chosen by early stopping.  Stage 2 refines the other parameters at random
# around the best depth.  Depth 1 = additive model, depth 2 = pairwise interactions, ...
_LADDER = {
    "lgbm": [dict(depth=1, leaves=2, lr=0.05, min_leaf=20, subsample=1.0, colsample=1.0, l2=0.0),
             dict(depth=2, leaves=4, lr=0.03, min_leaf=20, subsample=0.8, colsample=0.8, l2=1.0),
             dict(depth=3, leaves=8, lr=0.03, min_leaf=20, subsample=0.8, colsample=0.8, l2=1.0),
             dict(depth=4, leaves=15, lr=0.03, min_leaf=40, subsample=0.8, colsample=0.7, l2=1.0),
             dict(depth=6, leaves=31, lr=0.02, min_leaf=40, subsample=0.8, colsample=0.7, l2=3.0)],
    "xgb": [dict(depth=1, lr=0.05, mcw=5.0, subsample=1.0, colsample=1.0, l2=1.0),
            dict(depth=2, lr=0.03, mcw=5.0, subsample=0.8, colsample=0.8, l2=1.0),
            dict(depth=3, lr=0.03, mcw=5.0, subsample=0.8, colsample=0.7, l2=1.0),
            dict(depth=4, lr=0.03, mcw=5.0, subsample=0.8, colsample=0.7, l2=1.0),
            dict(depth=6, lr=0.02, mcw=10.0, subsample=0.8, colsample=0.6, l2=3.0)],
    "cat": [dict(depth=3, lr=0.05, l2=5.0, random_strength=1.0, bagging_temperature=1.0),
            dict(depth=4, lr=0.05, l2=5.0, random_strength=1.0, bagging_temperature=1.0),
            dict(depth=6, lr=0.05, l2=3.0, random_strength=1.0, bagging_temperature=1.0)],
}


def _ladder(family, prof, obj):
    """Stage-1 configurations of a family (cheapest / simplest first)."""
    if family in _LADDER:
        return [dict(c, class_weight=None) for c in _LADDER[family]]
    if family == "gam":
        return [dict(C=c, knots=8, class_weight=None) for c in (0.3, 1.0)]
    if family == "logreg":
        return [dict(C=c, class_weight=None) for c in (0.03, 0.3)]
    if family == "hgb":
        return [dict(depth=d, leaves=2 ** d, lr=0.05 if d < 3 else 0.03, min_leaf=30, l2=1.0, colsample=0.8,
                     class_weight=None) for d in (1, 2, 3, 5)]
    if family in ("et", "rf"):
        return [dict(n_estimators=400, min_leaf=ml, max_features=0.4, class_weight=None) for ml in (3, 10)]
    return [{}]


def _sample_params(family, rng, best, obj=None, prof=None):
    """Random draw around the best stage-1 configuration (``best``) of the family."""
    weights = [None]
    if prof and prof["imbalanced"] and obj is not None and obj.metric in ("roc_auc", "average_precision", "f1",
                                                                          "balanced_accuracy"):
        weights = [None, "balanced"]           # class weighting only where ranking/labels matter
    lu = lambda a, b: float(np.exp(rng.uniform(np.log(a), np.log(b))))
    cw = rng.choice(weights)
    if family in ("lgbm", "xgb", "cat", "hgb"):
        d0 = int(best.get("depth", 3))
        lo, hi = (1, 8) if family != "cat" else (2, 8)
        depth = int(np.clip(d0 + rng.integers(-1, 2), lo, hi))
    if family == "lgbm":
        return dict(depth=depth, leaves=int(rng.integers(2, 2 ** min(depth, 6) + 1)), lr=lu(0.015, 0.08),
                    min_leaf=int(lu(5, 200)), subsample=float(rng.uniform(0.5, 1.0)),
                    colsample=float(rng.uniform(0.3, 1.0)), l2=lu(1e-3, 30), l1=lu(1e-3, 3), class_weight=cw)
    if family == "xgb":
        return dict(depth=depth, lr=lu(0.015, 0.08), mcw=lu(1.0, 50.0), subsample=float(rng.uniform(0.5, 1.0)),
                    colsample=float(rng.uniform(0.3, 1.0)), l2=lu(1e-2, 30.0), l1=lu(1e-3, 3), class_weight=cw)
    if family == "cat":
        return dict(depth=depth, lr=lu(0.03, 0.1), l2=lu(1.0, 30.0), random_strength=lu(0.2, 5.0),
                    bagging_temperature=float(rng.uniform(0.0, 1.5)), class_weight=cw)
    if family == "hgb":
        return dict(depth=depth, leaves=int(rng.integers(2, 2 ** min(depth, 6) + 1)), lr=lu(0.02, 0.1),
                    min_leaf=int(lu(5, 200)), l2=lu(1e-2, 30), colsample=float(rng.uniform(0.4, 1.0)),
                    class_weight=cw)
    if family == "gam":
        return dict(C=lu(0.02, 3.0), knots=int(rng.choice([5, 6, 8, 10, 12])), class_weight=None)
    if family == "logreg":
        return dict(C=lu(1e-3, 10), class_weight=cw)
    if family in ("rf", "et"):
        return dict(n_estimators=400, min_leaf=int(rng.integers(1, 40)),
                    max_features=float(rng.choice([0.2, 0.3, 0.5, 0.7])),
                    class_weight=rng.choice(["balanced_subsample" if family == "rf" else "balanced"] + [None] * 3)
                    if weights != [None] else None)
    return {}


# =============================================================================
# 5. Cross-validation helpers
# =============================================================================
def _folds(y, n_splits, seed):
    skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return list(skf.split(np.zeros(len(y)), y))


def _oof_predict(spec, Xc, y, num_cols, cat_cols, folds, obj, n_jobs, early_stop=False):
    """OOF predictions; with ``early_stop`` the boosting families stop on the held-out fold and
    the mean best iteration is returned as well (used for tuning only)."""
    oof = np.zeros(len(y))
    iters = []
    for tr, va in folds:
        ev = (Xc.iloc[va], y[va]) if early_stop else None
        m = _fit_model(spec, Xc.iloc[tr], y[tr], num_cols, cat_cols, obj, n_jobs, eval_data=ev)
        oof[va] = m.predict(Xc.iloc[va])
        if m.best_iter is not None:
            iters.append(m.best_iter)
    return oof, (int(round(float(np.mean(iters)))) if iters else None)


def _logit(p):
    p = _clip(p)
    return np.log(p / (1 - p))


def _sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))


class PlattCalibrator:
    """Sigmoid map on the logit of the blended probability (2 parameters)."""

    def fit(self, p, y):
        z = self._z(p)
        self.lr_ = LogisticRegression(C=1e6, max_iter=1000).fit(z, y)
        return self

    @staticmethod
    def _z(p):
        return _logit(p)[:, None]

    def predict(self, p):
        return self.lr_.predict_proba(self._z(p))[:, 1]


# =============================================================================
# 6. The framework entry point
# =============================================================================
class StudentSolution:
    """
    Parameters
    ----------
    time_budget : seconds allowed for the tuning phase (the fresh-fold re-scoring and the final
                  refit are extra).  Small datasets finish well within it.
    n_splits    : number of stratified CV folds.
    random_state: global seed.
    verbose     : print progress.
    """

    def __init__(self, time_budget=200, n_splits=5, random_state=42, verbose=False, n_jobs=None):
        self.time_budget = time_budget
        self.n_splits = n_splits
        self.random_state = random_state
        self.verbose = verbose
        self.n_jobs = n_jobs if n_jobs else _N_CPU
        self.threshold_ = 0.5
        self.report_ = {}

    # ------------------------------------------------------------------ utils
    def _log(self, *a):
        if self.verbose:
            print("[framework]", *a, flush=True)

    @staticmethod
    def _blend_score(obj, y, logits):
        """Score of a blend given as a (members, n) logit matrix (higher = better).  Threshold
        metrics are optimised through log loss, a proper scoring rule that is far less noisy
        than the best-threshold cost on a finite OOF sample."""
        p = _sigmoid(logits.mean(0)) if logits.ndim == 2 else _sigmoid(logits)
        metric = obj.metric if obj.metric in ("roc_auc", "average_precision") else "log_loss"
        return _score_free(metric, y, p)

    # -------------------------------------------------------------------- fit
    def fit(self, X, y, metadata=None):
        t0 = time.time()
        rng = np.random.default_rng(self.random_state)
        obj = Objective(metadata)
        self.objective_ = obj
        y = np.asarray(y).ravel()
        classes = np.unique(y[~pd.isna(y)])
        pos = obj.positive_label
        if pos is not None and pos in classes.tolist() and not set(classes.tolist()) <= {0, 1, False, True}:
            y = (y == pos).astype(int)                          # metadata says which label is "positive"
        elif not set(classes.tolist()) <= {0, 1, False, True}:  # map arbitrary two-class labels to {0,1}
            y = (y == classes[-1]).astype(int)
        y = y.astype(int)

        X = pd.DataFrame(X).reset_index(drop=True)
        self.cleaner_ = DataCleaner(obj.id_columns, obj.target_name).fit(X)
        Xc = self.cleaner_.transform(X)
        num_cols, cat_cols = self.cleaner_.numeric_, self.cleaner_.categorical_
        prof = profile_data(Xc, y, self.cleaner_)
        self.profile_ = prof
        self._log("objective:", obj.describe())
        self._log("profile:", {k: v for k, v in prof.items() if k != "dropped"}, "dropped:", prof["dropped"])

        n = len(y)
        self.prior_ = float(np.clip(y.mean(), _EPS, 1 - _EPS))
        self.calibrator_ = None
        if Xc.shape[1] == 0 or len(np.unique(y)) < 2 or min(y.sum(), n - y.sum()) < 4:
            self.degenerate_ = True                       # nothing to learn: predict the prior
            self.threshold_ = 0.5
            return self
        self.degenerate_ = False

        # sub-sample for tuning on very large data (final fit still uses everything)
        if n > 60000:
            sub = rng.choice(n, 40000, replace=False)
            Xt, yt = Xc.iloc[sub].reset_index(drop=True), y[sub]
        else:
            Xt, yt = Xc, y
        n_splits = int(max(2, min(self.n_splits, yt.sum(), len(yt) - yt.sum())))
        folds_a = _folds(yt, n_splits, self.random_state)
        folds_b = _folds(yt, n_splits, self.random_state + 101)        # fresh folds for the final comparison

        # ---- baseline --------------------------------------------------------
        base = np.full(len(yt), yt.mean())
        self.report_["baseline_prior"] = {
            obj.tune_metric: _tuning_score(obj, yt, base),
            obj.metric: _selection_score(obj, yt, base)}

        # ---- candidate families ------------------------------------------------
        # the spline GAM is used when there are numerics but not so many that its design matrix explodes
        families = (["gam" if 0 < len(num_cols) <= 60 else "logreg"] + (["lgbm"] if _HAS_LGBM else ["hgb"])
                    + (["xgb"] if _HAS_XGB else []) + (["cat"] if _HAS_CAT else []) + ["et"])
        # Fractions of time_budget per family.  They are absolute (not renormalised), so an optional
        # family adds search time instead of starving the others; unused time rolls over.
        share = {"gam": 0.08, "logreg": 0.05, "lgbm": 0.30, "hgb": 0.30, "xgb": 0.25, "cat": 0.27, "et": 0.10}
        max_iter = {"gam": 6, "logreg": 6, "lgbm": 30, "hgb": 20, "xgb": 25, "cat": 12, "et": 5}
        tuned = {}                                                       # family -> list of (score, spec, n_trees)
        budget_end = t0
        hard_end = t0 + 2.5 * self.time_budget                            # never run away on slow machines
        search_log = []
        for fam in families:
            budget_end += self.time_budget * share[fam]
            # own random stream per family: the search does not change when another family is
            # added or a library is missing
            frng = np.random.default_rng([self.random_state, zlib.crc32(fam.encode())])
            results = []
            ladder = _ladder(fam, prof, obj)
            for it in range(max_iter[fam]):
                now = time.time()
                if it < len(ladder):
                    # the ladder always runs (unless hopelessly over time) so every family has a
                    # sensible model; the refinement is what the time box controls
                    if it > 0 and now > hard_end:
                        break
                    params = ladder[it]
                else:
                    if now > budget_end or not results:
                        break
                    params = _sample_params(fam, frng, best=max(results, key=lambda r: r[0])[1].params,
                                            obj=obj, prof=prof)
                spec = ModelSpec(fam, params, seed=self.random_state)
                try:
                    oof, n_trees = _oof_predict(spec, Xt, yt, num_cols, cat_cols, folds_a, obj, self.n_jobs,
                                                early_stop=True)
                    sc = _tuning_score(obj, yt, oof)
                except Exception as e:                                   # a failing config must never kill fit
                    self._log("config failed", spec.label(), repr(e))
                    continue
                results.append((sc, spec, n_trees))
                search_log.append((fam, sc, n_trees, spec.label()))
                self._log(f"{fam:5s} it{it:02d} {obj.tune_metric}={sc:.5f} trees={n_trees} t={time.time() - t0:5.0f}s")
            if results:
                results.sort(key=lambda r: -r[0])
                tuned[fam] = results
        self.report_["search"] = search_log
        if not tuned:                                                    # every candidate failed
            self.degenerate_ = True
            self.threshold_ = 0.5
            return self

        # ---- re-score best config of each family on fresh folds (fixed trees => no ES optimism) ----
        members, oofs = [], []
        for fam, res in tuned.items():
            sc, spec, n_trees = res[0]
            params = dict(spec.params)
            if n_trees is not None:
                params["n_estimators"] = int(max(20, n_trees))
            spec = ModelSpec(fam, params, seed=self.random_state)
            try:
                oof, _ = _oof_predict(spec, Xt, yt, num_cols, cat_cols, folds_b, obj, self.n_jobs)
            except Exception as e:
                self._log("re-score failed", spec.label(), repr(e))
                continue
            members.append(spec)
            oofs.append(oof)
            self._log(f"final-fold {fam:5s} {obj.metric}={_selection_score(obj, yt, oof):.5f} "
                      f"{obj.tune_metric}={_tuning_score(obj, yt, oof):.5f}")
        if not members:
            self.degenerate_ = True
            self.threshold_ = 0.5
            return self
        L = np.vstack([_logit(o) for o in oofs])                          # members x n, logit space
        self.report_["family_scores"] = {s.family: _selection_score(obj, yt, o) for s, o in zip(members, oofs)}
        self.report_["family_logloss"] = {s.family: -_score_free("log_loss", yt, o) for s, o in zip(members, oofs)}

        # ---- greedy ensemble selection (with replacement) in logit space ------------
        counts = np.zeros(len(members))
        singles = [self._blend_score(obj, yt, L[i]) for i in range(len(members))]
        best_i = int(np.argmax(singles))
        counts[best_i] = 1
        cur_score = singles[best_i]
        for k in range(2, 16):
            sc = []
            for i in range(len(members)):
                c = counts.copy()
                c[i] += 1
                sc.append(self._blend_score(obj, yt, np.tensordot(c / c.sum(), L, axes=1)))
            j = int(np.argmax(sc))
            if sc[j] > cur_score + 1e-6:
                cur_score = sc[j]
                counts[j] += 1
            else:
                break
        weights = counts / counts.sum()
        blend = _sigmoid(np.tensordot(weights, L, axes=1))
        self.report_["blend_weights"] = {m.family: float(w) for m, w in zip(members, weights) if w > 0}
        self.report_["blend_oof_score"] = float(_selection_score(obj, yt, blend))
        self.report_["blend_oof_logloss"] = float(-_score_free("log_loss", yt, blend))

        # ---- optional calibration (monotone => ranking preserved) ----------------
        try:
            inner = _folds(yt, n_splits, self.random_state + 202)
            cal_oof = np.zeros(len(yt))
            for tr, va in inner:
                cal_oof[va] = PlattCalibrator().fit(blend[tr], yt[tr]).predict(blend[va])
            ll_raw, ll_cal = -_score_free("log_loss", yt, blend), -_score_free("log_loss", yt, cal_oof)
            self.report_["logloss_blend_raw"], self.report_["logloss_blend_calibrated"] = ll_raw, ll_cal
            if ll_cal < ll_raw - 1e-5:
                self.calibrator_ = PlattCalibrator().fit(blend, yt)
                blend = self.calibrator_.predict(blend)
        except Exception as e:
            self._log("calibration skipped", repr(e))

        # ---- threshold ------------------------------------------------------------
        if obj.uses_threshold:
            self.threshold_ = self._robust_threshold(yt, blend, obj, rng)
            thr, tp, fp, fn, tn = _conf_curve(yt, blend)
            sc = _threshold_metric_from_counts(obj.metric, tp, fp, fn, tn, obj)
            self.report_["oof_best_score_at_optimum"] = float(sc.max())
            i = int(np.argmin(np.abs(thr - self.threshold_)))
            self.report_["oof_score_at_chosen_threshold"] = float(sc[i])
            self.report_["oof_score_at_0.5"] = float(sc[int(np.argmin(np.abs(thr - 0.5)))])
            if obj.metric == "cost":
                cost_fn = lambda t: (obj.fp_cost * ((blend >= t) & (yt == 0)).sum()
                                     + obj.fn_cost * ((blend < t) & (yt == 1)).sum())
                self.report_["oof_cost_per_1000"] = {
                    "chosen_threshold": 1000 * cost_fn(self.threshold_) / len(yt),
                    "bayes_threshold": 1000 * cost_fn(obj.fp_cost / (obj.fp_cost + obj.fn_cost)) / len(yt),
                    "predict_all_negative": 1000 * obj.fn_cost * yt.sum() / len(yt),
                    "predict_all_positive": 1000 * obj.fp_cost * (len(yt) - yt.sum()) / len(yt)}
                self.report_["bayes_threshold"] = obj.fp_cost / (obj.fp_cost + obj.fn_cost)
        else:
            self.threshold_ = 0.5

        # ---- refit chosen members on ALL data (several seeds for stochastic ones) --
        # Trees were counted on (k-1)/k of the tuning sample: scale up a little for the full data.
        grow = 1.0 + 0.5 / max(n_splits - 1, 1)
        if n > len(yt):
            grow *= min(1.5, (n / len(yt)) ** 0.5)
        self.models_, self.model_weights_ = [], []
        for spec, w in zip(members, weights):
            if w <= 0:
                continue
            params = dict(spec.params)
            if spec.family in _BOOSTERS and params.get("n_estimators"):
                params["n_estimators"] = int(round(params["n_estimators"] * grow))
            if spec.family in ("gam", "logreg", "prior"):
                seeds = [self.random_state]
            else:
                seeds = [self.random_state + 17 * s for s in range(3 if n < 40000 else 1)]
            fitted = []
            for s in seeds:
                try:
                    fitted.append(_fit_model(ModelSpec(spec.family, params, seed=s), Xc, y, num_cols, cat_cols,
                                             obj, self.n_jobs))
                except Exception as e:
                    self._log("refit failed", spec.label(), repr(e))
            for m in fitted:
                self.models_.append(m)
                self.model_weights_.append(w / len(fitted))
        if not self.models_:
            self.degenerate_ = True
            return self
        tw = float(sum(self.model_weights_))
        self.model_weights_ = [w / tw for w in self.model_weights_]
        self.report_["selected"] = [m.spec.label() for m in self.models_]
        self.report_["fit_seconds"] = time.time() - t0
        self._log("done in %.0fs; blend=%s threshold=%.4f" % (self.report_["fit_seconds"],
                                                                self.report_["blend_weights"], self.threshold_))
        return self

    # ----------------------------------------------------------- threshold
    @staticmethod
    def _robust_threshold(y, p, obj, rng, n_boot=200):
        """Median of bootstrap optima + average of the smoothed optimum (reduces curve noise)."""
        t_full, _ = _best_threshold(y, p, obj, smooth_window=max(5, len(y) // 400))
        ts = []
        n = len(y)
        for _ in range(n_boot):
            idx = rng.integers(0, n, n)
            t, _ = _best_threshold(y[idx], p[idx], obj, smooth_window=max(5, n // 400))
            ts.append(t)
        return float(np.clip(0.5 * (np.median(ts) + t_full), 1e-4, 1 - 1e-4))

    # ---------------------------------------------------------- inference
    def predict_proba(self, X, metadata=None):
        X = pd.DataFrame(X).reset_index(drop=True)
        if getattr(self, "degenerate_", False) or not getattr(self, "models_", None):
            return np.full(len(X), self.prior_)
        Xc = self.cleaner_.transform(X)
        z = np.zeros(len(Xc))
        for m, w in zip(self.models_, self.model_weights_):
            pm = m.predict(Xc)
            pm = np.where(np.isfinite(pm), pm, self.prior_)
            z += w * _logit(pm)                                  # members are blended in logit space
        p = _sigmoid(z)
        if self.calibrator_ is not None:
            p = self.calibrator_.predict(p)
        p = np.where(np.isfinite(p), p, self.prior_)            # never return NaN / inf
        return _clip(p)

    def get_threshold(self):
        return float(self.threshold_)

    # ------------------------------------------------------------- reporting
    def summary(self):
        r = dict(self.report_)
        r.pop("search", None)
        return {"objective": self.objective_.describe(), "profile": self.profile_, **r,
                "threshold": self.threshold_}
